# Python packages

This folder contains all the python source code for the projet, including the [library](lib/README.md) and the [diagnostic example app](diag/README.md).