# PSEC Diagnostic tool

## Dépendances

La construction du paquet wheel nécessite le module python `build` :
```
$ pip install build
```

**Une connexion Internet est nécessaire**

## Construction

```
$ python3 -m build --no-isolation
```
