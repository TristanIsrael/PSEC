from PySide6.QtCore import QDir

EVENT_TOUCH_BEGIN = "TouchBegin"
EVENT_TOUCH_UPDATE = "TouchUpdate"
EVENT_TOUCH_END = "TouchEnd"
