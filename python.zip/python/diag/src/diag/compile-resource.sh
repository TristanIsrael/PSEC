#!/bin/sh

pyside6-rcc ressources.qrc -o rc_ressources.py