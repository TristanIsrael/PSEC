#!/bin/sh

#while true
#do
        /usr/bin/python3 /usr/lib/psec/diag/src/diag/main.py -platform xcb 
#done
