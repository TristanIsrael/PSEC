# Bibliothèque python Panoptiscan

## Dépendances

La construction du paquet wheel nécessite le module python `build` :
```
$ pip install build
```

## Construction

```
$ python3 -m build
```
