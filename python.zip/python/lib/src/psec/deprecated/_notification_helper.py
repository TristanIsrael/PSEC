from ._message import TypeMessage
from ._notification import Notification
from ._type_evenement import TypeEvenement
from .._constantes import Constantes

class NotificationHelper:
    """ Cette classe permet de gérer les notifications.

    Les fonctions de cette classes sont statiques.
    """